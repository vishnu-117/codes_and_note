How to run code:
step 1:
run Pythone main.py file

step 2:
user can select options like 1,2,3
1. Book a FlightBooking
2. Book a HotelBooking
3. Book a Package Deal

step 3:
if user select 2 than hotel list will be visible like below and user can select hotel
0. Service id: HB004, Availability: 3, Price: 300
1. Service id: HB005, Availability: 2, Price: 450
2. Service id: HB006, Availability: 4, Price: 200

after that user will get reaponse like below:
Starting booking session...
[LOG] Booking attempt for function book_service with parameter (Travel service: HB005,2, 450,) and {}
[VALIDATED] Booking details are valid.
Booking service: Service id: HB005, Availability: 2, Price: 450
[LOG] Booking result Successfully booked Service id: HB005, Availability: 2, Price: 450
Successfully booked Service id: HB005, Availability: 2, Price: 450
Ending booking session...